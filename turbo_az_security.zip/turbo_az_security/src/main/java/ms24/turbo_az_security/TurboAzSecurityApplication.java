package ms24.turbo_az_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TurboAzSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(TurboAzSecurityApplication.class, args);
	}

}
