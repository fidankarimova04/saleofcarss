package ms24.turbo_az_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurboAzSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
